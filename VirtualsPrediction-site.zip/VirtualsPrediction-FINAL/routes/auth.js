const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { v4: uuidv4 } = require('uuid');
const { getUsers, saveUsers } = require('../utils/db');
require('dotenv').config();

const router = express.Router();

// Register
router.post('/register', async (req, res) => {
  try {
    const { username, password, mobile } = req.body;

    if (!username || !password || !mobile) {
      return res.status(400).json({ success: false, message: 'Username, password and mobile number are required.' });
    }

    if (username.length < 3) {
      return res.status(400).json({ success: false, message: 'Username must be at least 3 characters.' });
    }

    if (password.length < 6) {
      return res.status(400).json({ success: false, message: 'Password must be at least 6 characters.' });
    }

    // Basic mobile validation (Ghana style or general)
    const mobileClean = mobile.replace(/\s+/g, '');
    if (!/^\+?\d{9,15}$/.test(mobileClean)) {
      return res.status(400).json({ success: false, message: 'Please enter a valid mobile number.' });
    }

    const users = getUsers();

    if (users.find(u => u.username.toLowerCase() === username.toLowerCase())) {
      return res.status(400).json({ success: false, message: 'Username already exists.' });
    }

    if (users.find(u => u.mobile === mobileClean)) {
      return res.status(400).json({ success: false, message: 'Mobile number already registered.' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const newUser = {
      id: uuidv4(),
      username: username.trim(),
      password: hashedPassword,
      mobile: mobileClean,
      createdAt: new Date().toISOString(),
      activePackage: null,
      packageExpiry: null
    };

    users.push(newUser);
    saveUsers(users);

    const token = jwt.sign(
      { id: newUser.id, username: newUser.username },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES || '7d' }
    );

    res.status(201).json({
      success: true,
      message: 'Registration successful!',
      token,
      user: {
        id: newUser.id,
        username: newUser.username,
        mobile: newUser.mobile,
        activePackage: null
      }
    });
  } catch (err) {
    console.error('Register error:', err);
    res.status(500).json({ success: false, message: 'Server error during registration.' });
  }
});

// Login
router.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;

    if (!username || !password) {
      return res.status(400).json({ success: false, message: 'Username and password are required.' });
    }

    const users = getUsers();
    const user = users.find(u => u.username.toLowerCase() === username.toLowerCase());

    if (!user) {
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });
    }

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(401).json({ success: false, message: 'Invalid username or password.' });
    }

    // Check if package is still valid
    let activePackage = user.activePackage;
    if (user.packageExpiry && new Date(user.packageExpiry) < new Date()) {
      activePackage = null;
      // Update user
      user.activePackage = null;
      user.packageExpiry = null;
      saveUsers(users);
    }

    const token = jwt.sign(
      { id: user.id, username: user.username },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES || '7d' }
    );

    res.json({
      success: true,
      message: 'Login successful!',
      token,
      user: {
        id: user.id,
        username: user.username,
        mobile: user.mobile,
        activePackage: activePackage,
        packageExpiry: user.packageExpiry,
        sportybetConnected: user.sportybetConnected || false,
        sportybetId: user.sportybetId || null
      }
    });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ success: false, message: 'Server error during login.' });
  }
});

// Get current user profile
router.get('/me', require('../middleware/auth'), (req, res) => {
  try {
    const users = getUsers();
    const user = users.find(u => u.id === req.user.id);

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    // Check expiry
    let activePackage = user.activePackage;
    if (user.packageExpiry && new Date(user.packageExpiry) < new Date()) {
      activePackage = null;
      user.activePackage = null;
      user.packageExpiry = null;
      saveUsers(users);
    }

    res.json({
      success: true,
      user: {
        id: user.id,
        username: user.username,
        mobile: user.mobile,
        activePackage: activePackage,
        packageExpiry: user.packageExpiry,
        createdAt: user.createdAt,
        sportybetConnected: user.sportybetConnected || false,
        sportybetId: user.sportybetId || null
      }
    });
  } catch (err) {
    console.error('Profile error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
