const express = require('express');
const { v4: uuidv4 } = require('uuid');
const authenticateToken = require('../middleware/auth');
const { getUsers, saveUsers, getPurchases, savePurchases } = require('../utils/db');

const router = express.Router();

const PAYMENT_INFO = {
  network: 'MTN',
  number: '0557626059',
  name: 'Joseph Dadzie',
  instructions: 'Send the exact amount via MTN Mobile Money, then enter your Transaction ID below.'
};

const PACKAGES = {
  starter: {
    id: 'starter',
    name: 'Starter Package',
    price: 350,
    currency: 'GHS',
    durationDays: 7,
    description: 'Connect your Sportybet account, upload match screenshots and get instant scanned results (3 matches).',
    features: [
      'Connect Sportybet username/number',
      'Upload screenshot & get scanned results',
      '3 fixed high-confidence tips per scan',
      '7 days access'
    ]
  },
  pro: {
    id: 'pro',
    name: 'Pro Package',
    price: 700,
    currency: 'GHS',
    durationDays: 30,
    description: 'Full access to random Instant Virtual predictions up to 5 matches daily with high confidence.',
    features: [
      'All Starter features',
      'Random predictions up to 5 matches',
      'Daily refreshed tips',
      '30 days access',
      'Priority support'
    ]
  }
};

router.get('/', (req, res) => {
  res.json({
    success: true,
    packages: Object.values(PACKAGES),
    payment: PAYMENT_INFO
  });
});

// User submits payment → status = pending (waiting admin approval)
router.post('/purchase', authenticateToken, (req, res) => {
  try {
    const { packageId, transactionId, senderName } = req.body;

    if (!packageId || !PACKAGES[packageId]) {
      return res.status(400).json({ success: false, message: 'Invalid package selected.' });
    }

    if (!transactionId || transactionId.trim().length < 4) {
      return res.status(400).json({
        success: false,
        message: 'Please enter a valid MTN Mobile Money Transaction ID / Reference.'
      });
    }

    const pkg = PACKAGES[packageId];
    const users = getUsers();
    const user = users.find(u => u.id === req.user.id);

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    const purchases = getPurchases();

    const existingTx = purchases.find(
      p => p.transactionId && p.transactionId.toLowerCase() === transactionId.trim().toLowerCase()
    );
    if (existingTx) {
      return res.status(400).json({
        success: false,
        message: 'This Transaction ID has already been used.'
      });
    }

    const now = new Date();

    const purchase = {
      id: uuidv4(),
      userId: user.id,
      username: user.username,
      mobile: user.mobile,
      packageId: packageId,
      packageName: pkg.name,
      amount: pkg.price,
      currency: pkg.currency,
      transactionId: transactionId.trim(),
      senderName: (senderName || '').trim() || user.username,
      paymentNetwork: PAYMENT_INFO.network,
      paymentNumber: PAYMENT_INFO.number,
      paymentName: PAYMENT_INFO.name,
      purchasedAt: now.toISOString(),
      expiresAt: null,
      status: 'pending'
    };

    purchases.push(purchase);
    savePurchases(purchases);

    res.json({
      success: true,
      message: 'Payment submitted! Waiting for admin approval. You will get access once approved.',
      purchase: {
        id: purchase.id,
        packageName: pkg.name,
        amount: pkg.price,
        transactionId: purchase.transactionId,
        status: 'pending'
      }
    });
  } catch (err) {
    console.error('Purchase error:', err);
    res.status(500).json({ success: false, message: 'Server error during purchase.' });
  }
});

router.get('/history', authenticateToken, (req, res) => {
  try {
    const purchases = getPurchases();
    const userPurchases = purchases
      .filter(p => p.userId === req.user.id)
      .sort((a, b) => new Date(b.purchasedAt) - new Date(a.purchasedAt));

    res.json({ success: true, purchases: userPurchases });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

module.exports = router;
module.exports.PACKAGES = PACKAGES;
