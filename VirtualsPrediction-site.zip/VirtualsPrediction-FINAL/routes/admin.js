const express = require('express');
const jwt = require('jsonwebtoken');
const { getUsers, saveUsers, getPurchases, savePurchases } = require('../utils/db');
require('dotenv').config();

const router = express.Router();

// Simple admin auth middleware
function adminAuth(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];
  if (!token) {
    return res.status(401).json({ success: false, message: 'Admin token required' });
  }
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    if (!decoded.isAdmin) {
      return res.status(403).json({ success: false, message: 'Not an admin' });
    }
    req.admin = decoded;
    next();
  } catch (err) {
    return res.status(403).json({ success: false, message: 'Invalid admin token' });
  }
}

// Admin login
router.post('/login', (req, res) => {
  const { username, password } = req.body;
  const adminUser = process.env.ADMIN_USERNAME || 'admin';
  const adminPass = process.env.ADMIN_PASSWORD || 'admin1234';

  if (username === adminUser && password === adminPass) {
    const token = jwt.sign(
      { isAdmin: true, username: adminUser },
      process.env.JWT_SECRET,
      { expiresIn: '12h' }
    );
    return res.json({ success: true, token, message: 'Admin login successful' });
  }
  return res.status(401).json({ success: false, message: 'Invalid admin credentials' });
});

// List all purchases (admin)
router.get('/purchases', adminAuth, (req, res) => {
  try {
    const purchases = getPurchases();
    const sorted = purchases.sort((a, b) => new Date(b.purchasedAt) - new Date(a.purchasedAt));
    res.json({ success: true, purchases: sorted });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Approve a purchase
router.post('/approve/:purchaseId', adminAuth, (req, res) => {
  try {
    const { purchaseId } = req.params;
    const purchases = getPurchases();
    const idx = purchases.findIndex(p => p.id === purchaseId);

    if (idx === -1) {
      return res.status(404).json({ success: false, message: 'Purchase not found' });
    }

    const purchase = purchases[idx];
    if (purchase.status === 'approved') {
      return res.json({ success: true, message: 'Already approved' });
    }

    // Get package duration
    const durationDays = purchase.packageId === 'pro' ? 30 : 7;

    const users = getUsers();
    const userIdx = users.findIndex(u => u.id === purchase.userId);
    if (userIdx === -1) {
      return res.status(404).json({ success: false, message: 'User not found' });
    }

    const user = users[userIdx];
    const now = new Date();
    let startDate = now;
    if (user.packageExpiry && new Date(user.packageExpiry) > now) {
      startDate = new Date(user.packageExpiry);
    }
    const expiry = new Date(startDate);
    expiry.setDate(expiry.getDate() + durationDays);

    // Activate package
    user.activePackage = purchase.packageId;
    user.packageExpiry = expiry.toISOString();
    users[userIdx] = user;
    saveUsers(users);

    // Update purchase
    purchase.status = 'approved';
    purchase.expiresAt = expiry.toISOString();
    purchase.approvedAt = now.toISOString();
    purchases[idx] = purchase;
    savePurchases(purchases);

    res.json({
      success: true,
      message: `Approved! ${user.username} now has ${purchase.packageName} until ${expiry.toLocaleDateString()}`,
      purchase
    });
  } catch (err) {
    console.error('Approve error:', err);
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// Reject a purchase
router.post('/reject/:purchaseId', adminAuth, (req, res) => {
  try {
    const { purchaseId } = req.params;
    const purchases = getPurchases();
    const idx = purchases.findIndex(p => p.id === purchaseId);

    if (idx === -1) {
      return res.status(404).json({ success: false, message: 'Purchase not found' });
    }

    purchases[idx].status = 'rejected';
    purchases[idx].rejectedAt = new Date().toISOString();
    savePurchases(purchases);

    res.json({ success: true, message: 'Purchase rejected', purchase: purchases[idx] });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

// List all users (admin)
router.get('/users', adminAuth, (req, res) => {
  try {
    const users = getUsers().map(u => ({
      id: u.id,
      username: u.username,
      mobile: u.mobile,
      activePackage: u.activePackage,
      packageExpiry: u.packageExpiry,
      createdAt: u.createdAt,
      sportybetConnected: u.sportybetConnected || false,
      sportybetId: u.sportybetId || null
    }));
    res.json({ success: true, users });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error' });
  }
});

module.exports = router;
