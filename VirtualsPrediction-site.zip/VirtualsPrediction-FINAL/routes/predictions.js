const express = require('express');
const authenticateToken = require('../middleware/auth');
const { getUsers, saveUsers, getPredictions } = require('../utils/db');

const router = express.Router();

// Fixed results for Starter package screenshot scan
const STARTER_SCAN_RESULTS = [
  { match: 'First Match', prediction: 'GG → YES', confidence: 'High' },
  { match: 'Second Match', prediction: 'Home To Win', confidence: 'High' },
  { match: 'Third Match', prediction: 'Over 1.5 Goals', confidence: 'High' }
];

// Random prediction pools for Pro
const PRO_TEAMS = [
  'Virtual FC', 'Instant United', 'Cyber City', 'Digital Stars', 'Pixel Rangers',
  'Byte FC', 'Matrix United', 'Neon City', 'Quantum FC', 'Virtual Kings',
  'Algo Athletic', 'Data Drive', 'Code United', 'Script FC', 'Binary Stars'
];

const PRO_LEAGUES = [
  'Instant Virtual Premier', 'Instant Virtual League', 'Instant Virtual Cup',
  'Instant Virtual Championship', 'Virtual Super League'
];

const PRO_PREDICTIONS = [
  'Home Win', 'Away Win', 'Draw', 'Over 1.5 Goals', 'Over 2.5 Goals',
  'GG → YES', 'Both Teams to Score', 'Home Win & Over 1.5', 'Away Win & BTTS',
  'Under 3.5 Goals', '1X (Home or Draw)', 'X2 (Draw or Away)'
];

const PRO_CONFIDENCE = ['High', 'High', 'Medium', 'High', 'Medium'];

function generateProPredictions(count = 5) {
  const results = [];
  const used = new Set();
  for (let i = 0; i < count; i++) {
    let t1, t2;
    do {
      t1 = PRO_TEAMS[Math.floor(Math.random() * PRO_TEAMS.length)];
      t2 = PRO_TEAMS[Math.floor(Math.random() * PRO_TEAMS.length)];
    } while (t1 === t2 || used.has(t1 + t2));
    used.add(t1 + t2);

    const hour = 14 + Math.floor(Math.random() * 8);
    const min = Math.random() > 0.5 ? '00' : '30';

    results.push({
      id: 'pro-' + Date.now() + '-' + i,
      match: `${t1} vs ${t2}`,
      league: PRO_LEAGUES[Math.floor(Math.random() * PRO_LEAGUES.length)],
      prediction: PRO_PREDICTIONS[Math.floor(Math.random() * PRO_PREDICTIONS.length)],
      confidence: PRO_CONFIDENCE[Math.floor(Math.random() * PRO_CONFIDENCE.length)],
      odds: (1.5 + Math.random() * 2).toFixed(2),
      time: `Today ${hour}:${min}`
    });
  }
  return results;
}

// Get predictions based on package
router.get('/', authenticateToken, (req, res) => {
  try {
    const users = getUsers();
    const user = users.find(u => u.id === req.user.id);

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    if (!user.activePackage || !user.packageExpiry || new Date(user.packageExpiry) < new Date()) {
      if (user.activePackage) {
        user.activePackage = null;
        user.packageExpiry = null;
        saveUsers(users);
      }
      return res.status(403).json({
        success: false,
        message: 'No active package. Please purchase and wait for admin approval.',
        requiresPurchase: true
      });
    }

    if (user.activePackage === 'pro') {
      // Pro gets random 5 predictions
      const predictions = generateProPredictions(5);
      return res.json({
        success: true,
        package: 'pro',
        expiresAt: user.packageExpiry,
        predictions
      });
    }

    // Starter – they use the scan feature instead of list
    return res.json({
      success: true,
      package: 'starter',
      expiresAt: user.packageExpiry,
      message: 'Use Connect Sportybet and Upload Screenshot to get your predictions.',
      predictions: []
    });
  } catch (err) {
    console.error('Predictions error:', err);
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// Fake Sportybet connect
router.post('/connect-sportybet', authenticateToken, (req, res) => {
  try {
    const { sportybetId } = req.body;
    if (!sportybetId || sportybetId.trim().length < 3) {
      return res.status(400).json({ success: false, message: 'Please enter a valid Sportybet username or number.' });
    }

    const users = getUsers();
    const idx = users.findIndex(u => u.id === req.user.id);
    if (idx === -1) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    const user = users[idx];
    if (!user.activePackage || !user.packageExpiry || new Date(user.packageExpiry) < new Date()) {
      return res.status(403).json({ success: false, message: 'Active package required.' });
    }

    user.sportybetConnected = true;
    user.sportybetId = sportybetId.trim();
    users[idx] = user;
    saveUsers(users);

    // Fake delay feeling
    res.json({
      success: true,
      message: 'Connected successfully!',
      sportybetId: user.sportybetId
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error.' });
  }
});

// Fake screenshot scan (Starter)
router.post('/scan', authenticateToken, (req, res) => {
  try {
    const users = getUsers();
    const user = users.find(u => u.id === req.user.id);

    if (!user) {
      return res.status(404).json({ success: false, message: 'User not found.' });
    }

    if (!user.activePackage || !user.packageExpiry || new Date(user.packageExpiry) < new Date()) {
      return res.status(403).json({ success: false, message: 'Active package required.' });
    }

    // Accept any image data (base64) – we don't really process it
    const { imageData } = req.body;
    if (!imageData) {
      return res.status(400).json({ success: false, message: 'Please upload a screenshot.' });
    }

    // Always return the fixed 3 results for Starter
    res.json({
      success: true,
      message: 'Screenshot scanned successfully!',
      results: STARTER_SCAN_RESULTS
    });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Server error during scan.' });
  }
});

module.exports = router;
