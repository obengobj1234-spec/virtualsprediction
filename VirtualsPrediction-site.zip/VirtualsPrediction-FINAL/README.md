# VirtualsPrediction

Full Instant Virtual prediction platform with manual MTN MoMo payment + Admin approval.

## Payment Details
- **Network:** MTN
- **Number:** 0557626059
- **Name:** Joseph Dadzie

## Admin Login
- Username: `admin`
- Password: `admin1234`
(Change these in `.env`)

## Features

### Users
1. Register / Login
2. Buy Starter (350 GHS) or Pro (700 GHS) via MTN MoMo
3. Submit Transaction ID → status becomes **pending**
4. Admin approves → package activates

### Starter Package (350 GHS)
- Connect Sportybet username/number → shows **"Connected successfully"**
- Upload screenshot → fake scan returns:
  - First match: **GG → YES**
  - Second match: **Home To Win**
  - Third match: **Over 1.5 Goals**

### Pro Package (700 GHS)
- Random predictions up to **5 matches**
- Refreshable daily tips

### Admin Dashboard
- See all pending payments
- Approve or Reject
- View all purchase history with Transaction IDs

## Run
```bash
cd vp-site
npm install
npm start
```
Open http://localhost:3000

Admin link is at the bottom of the footer.
