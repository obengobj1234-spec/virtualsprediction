const API = '/api';
let currentUser = null;
let authToken = localStorage.getItem('vp_token') || null;
let adminToken = localStorage.getItem('vp_admin_token') || null;
let packagesCache = {};
let paymentInfo = null;
let scanImageData = null;

function showToast(message, type = 'info') {
  const toast = document.getElementById('toast');
  toast.textContent = message;
  toast.className = `toast ${type} show`;
  setTimeout(() => toast.classList.remove('show'), 4000);
}

function showPage(pageId) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  const page = document.getElementById(`page-${pageId}`);
  if (page) page.classList.add('active');
  document.getElementById('navLinks').classList.remove('open');

  if (pageId === 'packages') loadPackages();
  if (pageId === 'dashboard' && authToken) loadDashboard();
  if (pageId === 'predictions' && authToken) loadPredictions();
  if (pageId === 'connect' && authToken) loadConnectStatus();
  if (pageId === 'admin' && adminToken) loadAdminDashboard();
  if (pageId === 'adminLogin' && adminToken) showPage('admin');
}

function toggleMobileMenu() {
  document.getElementById('navLinks').classList.toggle('open');
}

function updateNav() {
  const isLoggedIn = !!authToken && !!currentUser;
  const hasPackage = isLoggedIn && currentUser.activePackage && currentUser.packageExpiry && new Date(currentUser.packageExpiry) > new Date();

  document.getElementById('navLogin').style.display = isLoggedIn ? 'none' : 'inline-block';
  document.getElementById('navRegister').style.display = isLoggedIn ? 'none' : 'inline-block';
  document.getElementById('navLogout').style.display = isLoggedIn ? 'inline-block' : 'none';
  document.getElementById('navDashboard').style.display = isLoggedIn ? 'inline-block' : 'none';
  document.getElementById('navPredictions').style.display = hasPackage ? 'inline-block' : 'none';
  document.getElementById('navConnect').style.display = hasPackage ? 'inline-block' : 'none';
  document.getElementById('navScan').style.display = hasPackage ? 'inline-block' : 'none';
}

async function apiCall(endpoint, options = {}, token = null) {
  const headers = { 'Content-Type': 'application/json', ...(options.headers || {}) };
  const t = token || authToken;
  if (t) headers['Authorization'] = `Bearer ${t}`;
  const res = await fetch(`${API}${endpoint}`, { ...options, headers });
  const data = await res.json();
  return { ok: res.ok, status: res.status, data };
}

// ---------- Auth ----------
async function handleRegister(e) {
  e.preventDefault();
  const btn = document.getElementById('regBtn');
  btn.disabled = true; btn.textContent = 'Creating...';
  try {
    const { ok, data } = await apiCall('/auth/register', {
      method: 'POST',
      body: JSON.stringify({
        username: document.getElementById('regUsername').value.trim(),
        mobile: document.getElementById('regMobile').value.trim(),
        password: document.getElementById('regPassword').value
      })
    });
    if (ok && data.success) {
      authToken = data.token;
      currentUser = data.user;
      localStorage.setItem('vp_token', authToken);
      localStorage.setItem('vp_user', JSON.stringify(currentUser));
      showToast('Account created!', 'success');
      updateNav();
      showPage('packages');
      document.getElementById('registerForm').reset();
    } else showToast(data.message || 'Registration failed', 'error');
  } catch { showToast('Network error', 'error'); }
  finally { btn.disabled = false; btn.textContent = 'Create Account'; }
}

async function handleLogin(e) {
  e.preventDefault();
  const btn = document.getElementById('loginBtn');
  btn.disabled = true; btn.textContent = 'Logging in...';
  try {
    const { ok, data } = await apiCall('/auth/login', {
      method: 'POST',
      body: JSON.stringify({
        username: document.getElementById('loginUsername').value.trim(),
        password: document.getElementById('loginPassword').value
      })
    });
    if (ok && data.success) {
      authToken = data.token;
      currentUser = data.user;
      localStorage.setItem('vp_token', authToken);
      localStorage.setItem('vp_user', JSON.stringify(currentUser));
      showToast('Welcome back!', 'success');
      updateNav();
      showPage('dashboard');
      document.getElementById('loginForm').reset();
    } else showToast(data.message || 'Login failed', 'error');
  } catch { showToast('Network error', 'error'); }
  finally { btn.disabled = false; btn.textContent = 'Login'; }
}

function logout() {
  authToken = null; currentUser = null;
  localStorage.removeItem('vp_token');
  localStorage.removeItem('vp_user');
  updateNav();
  showPage('home');
  showToast('Logged out', 'info');
}

async function checkAuth() {
  if (!authToken) { updateNav(); return; }
  try {
    const { ok, data } = await apiCall('/auth/me');
    if (ok && data.success) {
      currentUser = data.user;
      localStorage.setItem('vp_user', JSON.stringify(currentUser));
    } else logout();
  } catch {
    const saved = localStorage.getItem('vp_user');
    if (saved) currentUser = JSON.parse(saved);
  }
  updateNav();
}

// ---------- Packages ----------
async function loadPackages() {
  const grid = document.getElementById('packagesGrid');
  grid.innerHTML = '<p class="muted" style="text-align:center">Loading...</p>';
  try {
    const { ok, data } = await apiCall('/packages');
    if (!ok || !data.success) { grid.innerHTML = '<p class="muted">Failed to load.</p>'; return; }
    paymentInfo = data.payment;
    data.packages.forEach(p => packagesCache[p.id] = p);
    grid.innerHTML = data.packages.map(pkg => {
      const isPro = pkg.id === 'pro';
      return `<div class="package-card ${isPro ? 'pro' : ''}">
        ${isPro ? '<div class="package-badge">MOST POPULAR</div>' : ''}
        <div class="package-name">${pkg.name}</div>
        <div class="package-price">${pkg.price} <span>${pkg.currency}</span></div>
        <p class="package-desc">${pkg.description}</p>
        <ul class="package-features">${pkg.features.map(f => `<li>${f}</li>`).join('')}</ul>
        <button class="btn btn-primary btn-block" onclick="openPaymentModal('${pkg.id}')">
          ${authToken ? 'Buy with MTN MoMo' : 'Login to Purchase'}
        </button>
      </div>`;
    }).join('');
  } catch { grid.innerHTML = '<p class="muted">Failed to load.</p>'; }
}

function openPaymentModal(packageId) {
  if (!authToken) { showToast('Please login first', 'info'); showPage('login'); return; }
  const pkg = packagesCache[packageId];
  if (!pkg) return;
  document.getElementById('payPackageId').value = packageId;
  document.getElementById('payAmount').textContent = `${pkg.price} ${pkg.currency}`;
  document.getElementById('txId').value = '';
  document.getElementById('senderName').value = '';
  document.getElementById('paymentModal').style.display = 'flex';
}

function closePaymentModal() {
  document.getElementById('paymentModal').style.display = 'none';
}

async function submitPayment(e) {
  e.preventDefault();
  const btn = document.getElementById('paySubmitBtn');
  btn.disabled = true; btn.textContent = 'Submitting...';
  try {
    const { ok, data } = await apiCall('/packages/purchase', {
      method: 'POST',
      body: JSON.stringify({
        packageId: document.getElementById('payPackageId').value,
        transactionId: document.getElementById('txId').value.trim(),
        senderName: document.getElementById('senderName').value.trim()
      })
    });
    if (ok && data.success) {
      closePaymentModal();
      showToast(data.message, 'success');
      showPage('dashboard');
    } else showToast(data.message || 'Failed', 'error');
  } catch { showToast('Network error', 'error'); }
  finally { btn.disabled = false; btn.textContent = 'I Have Paid – Submit for Approval'; }
}

document.addEventListener('click', (e) => {
  if (e.target === document.getElementById('paymentModal')) closePaymentModal();
});

// ---------- Dashboard ----------
async function loadDashboard() {
  if (!currentUser) await checkAuth();
  document.getElementById('dashUsername').textContent = currentUser?.username || '-';
  document.getElementById('dashMobile').textContent = currentUser?.mobile || '-';
  document.getElementById('dashSporty').textContent = currentUser?.sportybetConnected
    ? `Connected (${currentUser.sportybetId})` : 'Not connected';

  const pkgInfo = document.getElementById('dashPackageInfo');
  if (currentUser?.activePackage && currentUser?.packageExpiry && new Date(currentUser.packageExpiry) > new Date()) {
    pkgInfo.innerHTML = `<div class="package-active">
      <div class="pkg-name">${currentUser.activePackage === 'pro' ? 'Pro Package' : 'Starter Package'}</div>
      <div class="pkg-expiry">Expires: ${new Date(currentUser.packageExpiry).toLocaleString()}</div>
    </div>
    <button class="btn btn-outline" style="margin-top:8px" onclick="showPage('predictions')">View Predictions</button>
    <button class="btn btn-primary" style="margin-top:8px;margin-left:8px" onclick="showPage('connect')">Connect Sportybet</button>
    <button class="btn btn-primary" style="margin-top:8px;margin-left:8px" onclick="showPage('scan')">Scan Screenshot</button>`;
  } else {
    pkgInfo.innerHTML = `<p class="no-package">No active package (waiting approval or expired)</p>
      <button class="btn btn-primary" onclick="showPage('packages')">Buy Package</button>`;
  }

  const hist = document.getElementById('purchaseHistory');
  try {
    const { ok, data } = await apiCall('/packages/history');
    if (ok && data.success && data.purchases.length) {
      hist.innerHTML = `<table class="history-table"><thead><tr>
        <th>Package</th><th>Amount</th><th>Tx ID</th><th>Status</th><th>Date</th>
      </tr></thead><tbody>
      ${data.purchases.map(p => `<tr>
        <td>${p.packageName}</td>
        <td>${p.amount} ${p.currency}</td>
        <td>${p.transactionId || '—'}</td>
        <td><span class="badge ${p.status === 'approved' ? 'badge-success' : p.status === 'pending' ? 'badge-pending' : 'badge-reject'}">${p.status}</span></td>
        <td>${new Date(p.purchasedAt).toLocaleDateString()}</td>
      </tr>`).join('')}
      </tbody></table>`;
    } else hist.innerHTML = '<p class="muted">No purchases yet.</p>';
  } catch { hist.innerHTML = '<p class="muted">Could not load history.</p>'; }
}

// ---------- Predictions ----------
async function loadPredictions() {
  const list = document.getElementById('predictionsList');
  const header = document.getElementById('predictionsHeader');
  list.innerHTML = '<p class="muted">Loading...</p>';
  header.innerHTML = '';
  try {
    const { ok, data, status } = await apiCall('/predictions');
    if (status === 403 || data.requiresPurchase) {
      list.innerHTML = `<div class="locked-message"><h3>🔒 Locked</h3><p>${data.message}</p>
        <button class="btn btn-primary" onclick="showPage('packages')">Buy Package</button></div>`;
      return;
    }
    if (!ok) { list.innerHTML = `<p class="muted">${data.message || 'Error'}</p>`; return; }

    if (data.package === 'starter') {
      header.innerHTML = `<p>Starter Package active • Use <strong>Connect Sportybet</strong> & <strong>Scan Screenshot</strong></p>`;
      list.innerHTML = `<div class="locked-message">
        <h3>Starter Tools</h3>
        <p>Connect your Sportybet account and upload screenshots to get scanned results.</p>
        <button class="btn btn-primary" onclick="showPage('connect')">Connect Sportybet</button>
        <button class="btn btn-primary" style="margin-left:8px" onclick="showPage('scan')">Scan Screenshot</button>
      </div>`;
      return;
    }

    // Pro
    header.innerHTML = `<p>Pro Package • Random predictions (up to 5 matches) • Expires ${new Date(data.expiresAt).toLocaleDateString()}</p>
      <button class="btn btn-outline" style="margin-top:8px" onclick="loadPredictions()">🔄 Refresh Predictions</button>`;
    if (!data.predictions?.length) {
      list.innerHTML = '<p class="muted">No predictions right now.</p>';
      return;
    }
    list.innerHTML = data.predictions.map(p => `
      <div class="prediction-card">
        <div>
          <div class="pred-match">${p.match}</div>
          <div class="pred-meta">${p.league} • ${p.time}</div>
          <div class="pred-tip">
            <span class="pred-result">${p.prediction}</span>
            <span class="pred-confidence conf-${(p.confidence||'').toLowerCase()}">${p.confidence} Confidence</span>
          </div>
        </div>
        <div class="pred-odds"><div class="odds-value">${p.odds}</div><div class="odds-label">Odds</div></div>
      </div>`).join('');
  } catch { list.innerHTML = '<p class="muted">Network error.</p>'; }
}

// ---------- Connect Sportybet ----------
function loadConnectStatus() {
  const el = document.getElementById('connectStatus');
  if (currentUser?.sportybetConnected) {
    el.innerHTML = `<div class="package-active" style="margin-bottom:16px">
      <div class="pkg-name">✓ Connected successfully</div>
      <div class="pkg-expiry">Sportybet ID: ${currentUser.sportybetId}</div>
    </div>`;
  } else {
    el.innerHTML = '';
  }
}

async function handleConnect(e) {
  e.preventDefault();
  const btn = document.getElementById('connectBtn');
  btn.disabled = true; btn.textContent = 'Connecting...';
  try {
    const { ok, data } = await apiCall('/predictions/connect-sportybet', {
      method: 'POST',
      body: JSON.stringify({ sportybetId: document.getElementById('sportybetId').value.trim() })
    });
    if (ok && data.success) {
      showToast('Connected successfully!', 'success');
      currentUser.sportybetConnected = true;
      currentUser.sportybetId = data.sportybetId;
      localStorage.setItem('vp_user', JSON.stringify(currentUser));
      loadConnectStatus();
      document.getElementById('connectForm').reset();
    } else showToast(data.message || 'Failed', 'error');
  } catch { showToast('Network error', 'error'); }
  finally { btn.disabled = false; btn.textContent = 'Connect Account'; }
}

// ---------- Scan Screenshot ----------
function previewScanImage(e) {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = (ev) => {
    scanImageData = ev.target.result;
    document.getElementById('scanPreviewImg').src = scanImageData;
    document.getElementById('scanPreview').style.display = 'block';
    document.getElementById('scanBtn').disabled = false;
    document.getElementById('scanResults').innerHTML = '';
  };
  reader.readAsDataURL(file);
}

async function handleScan() {
  if (!scanImageData) { showToast('Please select an image', 'error'); return; }
  const btn = document.getElementById('scanBtn');
  btn.disabled = true; btn.textContent = 'Scanning...';
  document.getElementById('scanResults').innerHTML = '<p class="muted">Analyzing screenshot...</p>';
  try {
    // Fake delay for "scanning"
    await new Promise(r => setTimeout(r, 1800));
    const { ok, data } = await apiCall('/predictions/scan', {
      method: 'POST',
      body: JSON.stringify({ imageData: scanImageData })
    });
    if (ok && data.success) {
      showToast('Scan complete!', 'success');
      document.getElementById('scanResults').innerHTML = `
        <h3 style="margin-bottom:12px; color:var(--success)">✓ Screenshot scanned successfully!</h3>
        ${data.results.map((r, i) => `
          <div class="prediction-card" style="margin-bottom:10px">
            <div>
              <div class="pred-match">${r.match}</div>
              <div class="pred-tip" style="margin-top:8px">
                <span class="pred-result">${r.prediction}</span>
                <span class="pred-confidence conf-high">${r.confidence} Confidence</span>
              </div>
            </div>
          </div>`).join('')}`;
    } else {
      document.getElementById('scanResults').innerHTML = `<p class="muted">${data.message || 'Scan failed'}</p>`;
      showToast(data.message || 'Scan failed', 'error');
    }
  } catch {
    document.getElementById('scanResults').innerHTML = '<p class="muted">Network error</p>';
    showToast('Network error', 'error');
  } finally {
    btn.disabled = false; btn.textContent = 'Scan Screenshot';
  }
}

// ---------- Admin ----------
async function handleAdminLogin(e) {
  e.preventDefault();
  try {
    const { ok, data } = await apiCall('/admin/login', {
      method: 'POST',
      body: JSON.stringify({
        username: document.getElementById('adminUser').value.trim(),
        password: document.getElementById('adminPass').value
      })
    }, null);
    if (ok && data.success) {
      adminToken = data.token;
      localStorage.setItem('vp_admin_token', adminToken);
      showToast('Admin login successful', 'success');
      showPage('admin');
    } else showToast(data.message || 'Invalid credentials', 'error');
  } catch { showToast('Network error', 'error'); }
}

function adminLogout() {
  adminToken = null;
  localStorage.removeItem('vp_admin_token');
  showPage('adminLogin');
  showToast('Admin logged out', 'info');
}

async function loadAdminDashboard() {
  if (!adminToken) { showPage('adminLogin'); return; }
  const pendingEl = document.getElementById('adminPending');
  const allEl = document.getElementById('adminAllPurchases');
  pendingEl.innerHTML = '<p class="muted">Loading...</p>';
  allEl.innerHTML = '<p class="muted">Loading...</p>';

  try {
    const { ok, data } = await apiCall('/admin/purchases', {}, adminToken);
    if (!ok) {
      if (data.message?.includes('token') || data.message?.includes('admin')) {
        adminLogout();
        return;
      }
      pendingEl.innerHTML = '<p class="muted">Error loading</p>';
      return;
    }

    const pending = data.purchases.filter(p => p.status === 'pending');
    const all = data.purchases;

    if (pending.length === 0) {
      pendingEl.innerHTML = '<p class="muted">No pending payments.</p>';
    } else {
      pendingEl.innerHTML = `<table class="history-table"><thead><tr>
        <th>User</th><th>Package</th><th>Amount</th><th>Tx ID</th><th>Sender</th><th>Date</th><th>Action</th>
      </tr></thead><tbody>
      ${pending.map(p => `<tr>
        <td>${p.username}<br><small>${p.mobile || ''}</small></td>
        <td>${p.packageName}</td>
        <td>${p.amount} ${p.currency}</td>
        <td><strong>${p.transactionId}</strong></td>
        <td>${p.senderName || '—'}</td>
        <td>${new Date(p.purchasedAt).toLocaleString()}</td>
        <td>
          <button class="btn btn-primary" style="padding:6px 12px;font-size:0.85rem" onclick="approvePurchase('${p.id}')">Approve</button>
          <button class="btn btn-outline" style="padding:6px 12px;font-size:0.85rem;margin-left:4px" onclick="rejectPurchase('${p.id}')">Reject</button>
        </td>
      </tr>`).join('')}
      </tbody></table>`;
    }

    allEl.innerHTML = `<table class="history-table"><thead><tr>
      <th>User</th><th>Package</th><th>Amount</th><th>Tx ID</th><th>Status</th><th>Date</th>
    </tr></thead><tbody>
    ${all.map(p => `<tr>
      <td>${p.username}</td>
      <td>${p.packageName}</td>
      <td>${p.amount} ${p.currency}</td>
      <td>${p.transactionId}</td>
      <td><span class="badge ${p.status === 'approved' ? 'badge-success' : p.status === 'pending' ? 'badge-pending' : 'badge-reject'}">${p.status}</span></td>
      <td>${new Date(p.purchasedAt).toLocaleDateString()}</td>
    </tr>`).join('')}
    </tbody></table>`;
  } catch {
    pendingEl.innerHTML = '<p class="muted">Network error</p>';
  }
}

async function approvePurchase(id) {
  if (!confirm('Approve this payment and activate the package?')) return;
  try {
    const { ok, data } = await apiCall(`/admin/approve/${id}`, { method: 'POST' }, adminToken);
    if (ok && data.success) {
      showToast(data.message, 'success');
      loadAdminDashboard();
    } else showToast(data.message || 'Failed', 'error');
  } catch { showToast('Network error', 'error'); }
}

async function rejectPurchase(id) {
  if (!confirm('Reject this payment?')) return;
  try {
    const { ok, data } = await apiCall(`/admin/reject/${id}`, { method: 'POST' }, adminToken);
    if (ok && data.success) {
      showToast('Rejected', 'info');
      loadAdminDashboard();
    } else showToast(data.message || 'Failed', 'error');
  } catch { showToast('Network error', 'error'); }
}

// ---------- Init ----------
document.addEventListener('DOMContentLoaded', () => {
  checkAuth();
  if (adminToken) { /* keep it */ }
  showPage('home');
});
