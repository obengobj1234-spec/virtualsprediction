const fs = require('fs');
const path = require('path');

const dataDir = path.join(__dirname, '..', 'data');

function readJSON(filename) {
  const filePath = path.join(dataDir, filename);
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    return [];
  }
}

function writeJSON(filename, data) {
  const filePath = path.join(dataDir, filename);
  fs.writeFileSync(filePath, JSON.stringify(data, null, 2));
}

module.exports = {
  getUsers: () => readJSON('users.json'),
  saveUsers: (users) => writeJSON('users.json', users),
  getPurchases: () => readJSON('purchases.json'),
  savePurchases: (purchases) => writeJSON('purchases.json', purchases),
  getPredictions: () => readJSON('predictions.json'),
  savePredictions: (predictions) => writeJSON('predictions.json', predictions)
};
